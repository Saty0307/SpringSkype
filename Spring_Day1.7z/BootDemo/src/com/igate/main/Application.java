package com.igate.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.igate.dto.MyBean;
/*
 * The Application runner
 * Author:hg676412
 * Version: 1.0
 */
@Configuration
@EnableAutoConfiguration
@ComponentScan("com.igate")
public class Application {

    public static void main(String[] args) {
    	ApplicationContext ctx = SpringApplication.run(Application.class, args);
    	MyBean mb=ctx.getBean(MyBean.class);
    	System.out.println("My Name is :"+mb.getName());
    	
    }

}
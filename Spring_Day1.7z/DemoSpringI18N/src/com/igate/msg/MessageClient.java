package com.igate.msg;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageClient {
	public static void main(String args[]) throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("message.xml");
		MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
		Locale locale = new Locale("in","TG");
		Object[] o1=new Object[2];
		o1[0]="Thank You!";
		o1[1]="Daren";
		String msg = messageSource.getMessage("welcome.message",o1,locale);
		System.out.println(msg);
		//<h1>${welcome.message}</h1>
	}
}

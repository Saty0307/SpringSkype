package com.igate.intro;

public class Employee {
 int empId;
 String name;
 float sal;
 
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getSal() {
	return sal;
}
public void setSal(float sal) {
	this.sal = sal;
}
 
public float calcPF(float rate)
{
	return sal*rate/100;
}
}

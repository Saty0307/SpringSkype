package com.igate.intro;

public class Address {
  int doorNo;
  String street;
  String city;
  int pincode;
  
	public Address() {
		super();
	}
	
	public Address(int doorNo, String street, String city,int pincode) {
		super();
		this.doorNo = doorNo;
		this.street = street;
		this.city = city;
		this.pincode=pincode;
	}

}

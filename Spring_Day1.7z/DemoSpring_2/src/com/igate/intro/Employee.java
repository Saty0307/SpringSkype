package com.igate.intro;

public class Employee {
 int empId;
 String name;
 float sal;
 

public Employee(int empId, String name, float sal) {
	super();
	this.empId = empId;
	this.name = name;
	this.sal = sal;
}

public Employee(int empId, String name) {
	super();
	this.empId = empId;
	this.name = name;
	this.sal = 92000f;
}


public float calcPF(float rate)
{
	return sal*rate/100;
}
}

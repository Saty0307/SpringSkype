package com.igate.emp;

public class Employee {
 int empId;
 String name;
 float sal;
 Address resAddr;

@Override
public String toString() {
	return "Employee [empId=" + empId + ", name=" + name + ", sal=" + sal
			+ ", resAddr=" + resAddr + "]";
}


public int getEmpId() {
	return empId;
}


public void setEmpId(int empId) {
	this.empId = empId;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public float getSal() {
	return sal;
}


public void setSal(float sal) {
	this.sal = sal;
}


public Address getResAddr() {
	return resAddr;
}


public void setResAddr(Address resAddr) {
	this.resAddr = resAddr;
}


public float calcPF(float rate)
{
	return sal*rate/100;
}
}

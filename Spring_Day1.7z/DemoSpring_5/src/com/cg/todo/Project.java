package com.cg.todo;

import java.util.ArrayList;

public class Project {
int ProjectId;

ArrayList<Resource> team;

public int getProjectId() {
	return ProjectId;
}

public void setProjectId(int projectId) {
	ProjectId = projectId;
}

public ArrayList<Resource> getTeam() {
	return team;
}

public void setTeam(ArrayList<Resource> team) {
	this.team = team;
}
}

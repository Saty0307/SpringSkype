package com.cg.todo;

public class Resource {
 int empId;
 String name;
 String loc;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLoc() {
	return loc;
}
public void setLoc(String loc) {
	this.loc = loc;
}
@Override
public String toString() {
	return "Resource [empId=" + empId + ", name=" + name + ", loc=" + loc + "]";
}
 
}

package com.igate.bfpp;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class UserClient {

	public static void main(String args[]) throws Exception {
	//	ApplicationContext ctx = new ClassPathXmlApplicationContext("user.xml");
	//	User user = (User) ctx.getBean("user");
	//	System.out.println(user.getUsername());
	//	System.out.println(user.getPassword());
		
		Resource res = new ClassPathResource("user.xml");
		ConfigurableListableBeanFactory factory = new XmlBeanFactory(res);
		PropertyPlaceholderConfigurer cfg = new PropertyPlaceholderConfigurer();
		cfg.setLocation(new FileSystemResource("C:\\D_Drive\\Hema_Contents\\java_jee\\Spring\\Spring3-Demos\\DemoSpring_6\\src\\user.properties"));
		cfg.postProcessBeanFactory(factory);
		User user = (User) factory.getBean("user");
		System.out.println(user.getUsername());			
	}
}

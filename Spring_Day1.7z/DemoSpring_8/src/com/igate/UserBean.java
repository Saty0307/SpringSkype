package com.igate;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("u")
public class UserBean {
		
	//@Value("199")
	@Value("${userid}")
	private int userId;
		
   // @Value("majrul")
	@Value("${uname}")
	private String username;
	
	//@Value("majrul123")
	@Value("${password}")
	private String password;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}

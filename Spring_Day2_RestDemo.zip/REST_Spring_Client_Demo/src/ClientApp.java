import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.client.RestTemplate;

public class ClientApp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		RestTemplate template = ctx.getBean(RestTemplate.class);
		String response = template
				.getForObject(
						"http://localhost:8080/REST_Spring4/service/employee/104",
						String.class);
		System.out.println("Employee Details : \n" + response);
		 response = template
				.getForObject(
						"http://localhost:8080/REST_Spring4/service/employees",
						String.class);
		System.out.println("List of Employees : \n" + response);

	}

}

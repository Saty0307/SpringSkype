package com.igate.rest.json;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.igate.rest.bean.Product;

/**
 * @author bb813366
 * Use http://localhost:8080/REST_withJSONDemo/json/product/get
 */
@Path("/product")
public class JSONService {
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public Product getProductInJSON() {

		Product prod = new Product();
		prod.setProdId("p101");
		prod.setProdName("Television");
		prod.setPrice(12345);
		return prod;

	}

	 /*@POST
		@Path("/create")
		@Consumes("application/json")
		public void createProductInJSON(Product product) {
		 	System.out.println("********************************");
			String result = "Product created : " + product;
			//return Response.status(201).entity(result).build();
			System.out.println(result);
	 
		}
*/

}

package com.igate.rest.xml;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
//import javax.ws.rs.core.MediaType;

import com.igate.rest.bean.Customer;

/**
 * @author bb813366
 * Use http://localhost:8080/REST_withXMLDemo/xml/customer/1 to run the application
 */
@Path("/customer")
public class XMLService {

	@GET
	@Path("/{custId}")
	//@Produces(MediaType.APPLICATION_XML) OR
	@Produces("application/xml")
	public Customer getCustomerInXML(@PathParam("custId") String custId) {

		Customer customer = new Customer();
		customer.setCustId(custId);
		customer.setCustName("John 	Mitchell");
		customer.setAddress("Pune");

		return customer;

	}

}

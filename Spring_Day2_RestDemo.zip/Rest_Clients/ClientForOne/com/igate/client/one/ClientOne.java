package com.igate.client.one;
import org.springframework.web.client.RestTemplate;


public class ClientOne {
	public static void main(String args[]) {
		RestTemplate restTemplate = new RestTemplate();
		User user = restTemplate.getForObject("http://localhost:8083/Spring_REST_One/user/5", User.class);
		System.out.println(user);
		System.out.println(user.getUserName());
		
	
		
	}
}

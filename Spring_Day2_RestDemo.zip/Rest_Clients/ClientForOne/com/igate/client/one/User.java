package com.igate.client.one;


import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class User {

	@Override
	public String toString() {
		return "User [userid=" + userid + ", userName=" + userName
				+ ", password=" + password + ", email=" + email + "]";
	}

	private int userid;
	private String userName;
	private String password;
	private String email;

	public User(){}
	public User(int userId, String userName, String password, String email) {
		super();
		this.userid = userId;
		this.userName = userName;
		this.password = password;
		this.email = email;
	}

	public int getUserId() {
		return userid;
	}

	public void setUserId(int userId) {
		this.userid = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}

import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



public class PutClient {

	public static void main(String[] args) {
		RestTemplate restTemplate = new RestTemplate();
		String getURL ="http://localhost:8080/Spring_REST_PUT_Demo/user/1";
		User user = restTemplate.getForObject(getURL, User.class);
		System.out.println(user.getUserName());
		String putURL ="http://localhost:8080/Spring_REST_PUT_Demo/update/user";
		user.setUserName(user.getUserName()+"xxxx");
		restTemplate.put(putURL,user );
		user = restTemplate.getForObject(getURL, User.class);
		ObjectMapper mapper = new ObjectMapper();
		try {
			System.out.println("JSON Object : "+mapper.writeValueAsString(user));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}
}

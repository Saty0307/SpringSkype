import java.io.IOException;
import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;




public class PutWithJsonClient {

	public static void main(String[] args) {
		RestTemplate restTemplate = new RestTemplate();
		String JSON = "{\"userId\":1,\"userName\":\"Ram\",\"password\":\"Ram123456\",\"email\":\"ram@igate.com\"}";
		String putURL ="http://localhost:8080/Spring_REST_PUT_Demo/update/user";
		//Convert JSON to Java Object
		ObjectMapper mapper = new ObjectMapper();
		User user = null;
		try {
			user = mapper.readValue(JSON, User.class);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<String> requestEntity = new HttpEntity<String>(JSON,headers);
			restTemplate.put(putURL,requestEntity);
			user = restTemplate.getForObject("http://localhost:8080/Spring_REST_PUT_Demo/user/1", User.class);
			System.out.println("JSON Object : "+mapper.writeValueAsString(user));
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
}

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.igate.client.two.User;

public class PostXML {

	public static void main(String[] args) throws Exception {

		// Get file to be posted
		String strXMLFilename = "user.xml";
		File input = new File(strXMLFilename);
		// Convert XML to Java object with JAX-B
		JAXBContext context = JAXBContext.newInstance(User.class);
		Unmarshaller un = context.createUnmarshaller();
		User user = (User) un.unmarshal(input);
		System.out.println(user);
		RestTemplate restTemplate = new RestTemplate();
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		 
		//Add the Jackson Message converter
		messageConverters.add(new MappingJacksonHttpMessageConverter());
		 
		//Add the message converters to the restTemplate
		restTemplate.setMessageConverters(messageConverters); 
		User result2 = restTemplate.postForObject("http://localhost:8089/Spring_REST_JSON_Two/adduser", user, User.class);
		System.out.println("ADDED : "+result2);

	}
}
package com.igate.test;

import java.util.ArrayList;
import java.util.List;


import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.igate.client.two.User;

public class Client {

	public static void main(String[] args) {
		RestTemplate restTemplate = new RestTemplate();
		 
		//Create a list for the message converters
		 
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		 
		//Add the Jackson Message converter
		messageConverters.add(new MappingJacksonHttpMessageConverter());
		 
		//Add the message converters to the restTemplate
		restTemplate.setMessageConverters(messageConverters); 
		 
		//A simple GET request, the response will be mapped to Example.class
		User result = restTemplate.getForObject("http://localhost:8083/Spring_REST_JSON_Two/user/4", User.class);
		 
		System.out.println(result);
		//Create an object which can be sent with the POST request
		User u1 = new User(18, "MY_Baby", "new123", "new@igate.com");
						 
		//The POST request.
		User result2 = restTemplate.postForObject("http://localhost:8083/Spring_REST_JSON_Two/adduser", u1, User.class);
		System.out.println("ADDED : "+result2);

	}
}

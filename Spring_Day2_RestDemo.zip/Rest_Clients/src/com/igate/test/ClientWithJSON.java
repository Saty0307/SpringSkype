package com.igate.test;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.igate.client.two.User;

public class ClientWithJSON {

	public static void main(String[] args) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		RestTemplate template = new RestTemplate();

		String jsonObj = "{\"userid\":102,\"firstName\":\"Just\",\"lastName\":\"Guest\",\"email\":\"just@igate.com\"}";
		HttpEntity<String> requestEntity = new HttpEntity<String>(jsonObj,headers);

		ResponseEntity<User> entity = template.postForEntity(
				"http://localhost:8089/Spring_REST_JSON_Two/adduser",
				requestEntity, User.class);
	
		System.out.println(entity.getHeaders());
		
	}

}

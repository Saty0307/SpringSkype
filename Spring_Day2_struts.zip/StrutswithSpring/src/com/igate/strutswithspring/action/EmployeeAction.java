/**
 * 
 */
package com.igate.strutswithspring.action;

import java.util.Map;

import org.apache.struts2.interceptor.RequestAware;
import org.springframework.beans.factory.annotation.Autowired;

import com.igate.strutswithspring.bo.IEmployeeBO;
import com.igate.strutswithspring.employee.Employee;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * @author 717503
 *
 */
public class EmployeeAction extends ActionSupport implements ModelDriven<Employee>, RequestAware{
	@Autowired
	private IEmployeeBO employeeBO;
	private Employee employee;
	private Map request;
	public Map getRequest() {
		return request;
	}

	public void setRequest(Map request) {
		this.request = request;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public IEmployeeBO getEmployeeBO() {
		return employeeBO;
	}

	public void setEmployeeBO(IEmployeeBO employeeBO) {
		this.employeeBO = employeeBO;
	}
	
	public String addEmployee()
	{
		String employeeCode=employeeBO.addEmployee(employee);
		System.out.println("employee action");
		request.put("employeeCode",employeeCode);
		return "success";
	}

	@Override
	public Employee getModel() {
		// TODO Auto-generated method stub
		return employee;
	}
}

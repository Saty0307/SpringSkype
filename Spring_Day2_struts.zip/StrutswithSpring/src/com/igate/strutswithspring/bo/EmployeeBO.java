/**
 * 
 */
package com.igate.strutswithspring.bo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.strutswithspring.dao.IEmployeeDAO;
import com.igate.strutswithspring.employee.Employee;

/**
 * @author 717503
 *
 */
@Component
public class EmployeeBO implements IEmployeeBO{
	@Autowired
	private IEmployeeDAO employeeDAO;
	
	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public String addEmployee(Employee employee)
	{
		System.out.println("employee bo");
		String employeeCode=employeeDAO.addEmployee(employee);
		return employeeCode;
		
	}
}

/**
 * 
 */
package com.igate.strutswithspring.bo;

import com.igate.strutswithspring.employee.Employee;

/**
 * @author 717503
 *
 */
public interface IEmployeeBO {
	public String addEmployee(Employee employee);
}

/**
 * 
 */
package com.igate.strutswithspring.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.igate.strutswithspring.employee.Employee;

@Repository
public class EmployeeDAO implements IEmployeeDAO{
	
	
	
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public String addEmployee(Employee employee)
	{
		String employeeCode="717503";
		Integer empCode=0;
		//(Integer)employee.setEmployeeCode(empCode);
		 empCode=(Integer)hibernateTemplate.save(employee);
		/*System.out.println("EmployeeDAO");
		//jdbcTemplate.update("INSERT INTO employee_struts VALUES(?,?,?)",new Object[]{employeeCode, employee.getEmployeeName(),employee.getEmployeeCity()});
		jdbcTemplate.update("call employee_struts_employee(?,?,?)",new Object[]{employeeCode, employee.getEmployeeName(),employee.getEmployeeCity()});
		CallableStatementCreatorFactory creatorFactory=new CallableStatementCreatorFactory("call employee_struts_employee(?,?,?)");
		creatorFactory.addParameter(new SqlParameter("i_emplolyee_name",Types.VARCHAR));
		creatorFactory.addParameter(new SqlOutParameter("o_employee_code",Types.VARCHAR));
		creatorFactory.addParameter(new SqlParameter("i_employee_city",Types.VARCHAR));*/
		
		//return employeeCode;
		 return empCode.toString();
	}

}

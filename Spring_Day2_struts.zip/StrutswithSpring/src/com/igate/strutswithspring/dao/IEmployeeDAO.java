/**
 * 
 */
package com.igate.strutswithspring.dao;

import com.igate.strutswithspring.employee.Employee;

/**
 * @author 717503
 *
 */
public interface IEmployeeDAO {
	public String addEmployee(Employee employee);
}

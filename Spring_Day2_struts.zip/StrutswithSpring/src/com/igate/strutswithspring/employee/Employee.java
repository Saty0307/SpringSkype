/**
 * 
 */
package com.igate.strutswithspring.employee;

/**
 * @author 717503
 *
 */
public class Employee {
	
	private Integer employeeCode;
	private String employeeName;
	private String employeeCity;
	public Integer getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(Integer employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeCity() {
		return employeeCity;
	}
	public void setEmployeeCity(String employeeCity) {
		this.employeeCity = employeeCity;
	}
	

}

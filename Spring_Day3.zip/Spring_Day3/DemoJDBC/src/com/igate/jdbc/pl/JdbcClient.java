package com.igate.jdbc.pl;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;

import com.igate.jdbc.bean.Employee;
import com.igate.jdbc.service.EmployeeService;

public class JdbcClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext bf = new ClassPathXmlApplicationContext("jdbc.xml");
		EmployeeService service = (EmployeeService) bf
				.getBean("employeeService");

		
		  //execute queryForInt 
			int count=service.getCount();
			System.out.println("No of Employees in the table :"+count);
			System.out.println("--------------------");
			
			try{			
			String name=service.getEmployeeName(333);
			System.out.println("Name "+name);
			}catch (EmptyResultDataAccessException e) 
			{
				System.out.println("The Employee ID is invalid");
			}catch (DataAccessException e) {
				System.out.println(e.getMessage());
			}
			
			try{			
			System.out.println("--------Insert Employee-----------");
			int Icount=service.insertRec(88,"Swathi",90232);
			if(Icount>0)
				System.out.println("Record inserted successfully.......");
			else
				System.out.println("Error in insertion........");
			}catch (DuplicateKeyException e) 
			{
				System.out.println("Employee Id already exist..should be unique");
			}catch (DataAccessException e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println("--------Update Employee-----------");
			int Ucount=service.updateRec(99,"Daniel",78000);
			if(Ucount>0)
				System.out.println("Record updated successfully.......");
			else
				System.out.println("Error in updation........");
			
			System.out.println("--------Query for List-----------");
			
			List list=service.getAll();
			if(list!=null){
				System.out.println("Listing the employees...");
				for(Object e:list){
					System.out.println(e);
				}
			}
			
			System.out.println("--------Query for Employees-----------");
			
			List<Employee> list1=service.getEmployeeList();
			if(list1!=null){
				System.out.println("Listing the employees...");
				for(Employee e:list1){
					System.out.println(e.getEid()+" "+e.getEnm()+" "+e.getEsl());
				}
			}
			
			System.out.println("--------Query for Employee with id 99-----------");
			try
			  {
			  Employee employee=service.getEmpByEid(99);
			  System.out.println("Employee Info");
			  System.out.println("EID :"+employee.getEid());
			  System.out.println("ENM :"+employee.getEnm());
			  System.out.println("ESL :"+employee.getEsl());
			  }catch (EmptyResultDataAccessException e) 
				{
					System.out.println("The Employee ID is invalid");
				} catch (DataAccessException e) {
					System.out.println(e.getMessage());
				}

	}
	
	

}

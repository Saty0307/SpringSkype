package com.igatepatni.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.igatepatni.entity.Contact;

@Controller("contactController")
public class ContactController {

	List<Contact> list;
	public ContactController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*public ContactController(ContactDao contactDao) {
		super();
		this.contactDao = contactDao;
		System.out.println("contact dao :" + contactDao);
	}*/

	@Autowired
	private ContactDao contactDao;

	@RequestMapping(value = "/contact")
	public ModelAndView contacts(HttpServletRequest request) {
		// Handle a new guest (if any):
		System.out.println("in contacts - 1");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		if (name != null && email != null){
			list = contactDao.persistContact(new Contact(name, email));
			System.out.println("in contacts - 2");
			// list = contactDao.getAllContacts();
			//System.out.println(list);
			//model.addAttribute("contactDao",contactDao);
		}
		
		return new ModelAndView("contact","contactDao",list);
	}
}
package com.igatepatni.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.igatepatni.entity.Contact;

@Component("contactDao")
@Transactional(propagation = Propagation.REQUIRED)
public class ContactDao {
	// Injected database connection

	@PersistenceContext
	private EntityManager entityManager;


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	// Stores a new guest:
	

	public List<Contact> persistContact(Contact contact) {
		entityManager.persist(contact);
		System.out.println("in persist");
		System.out.println("in get contacts");
		Query query = entityManager.createQuery("FROM Contact");
		System.out.println("Query : " + query);
		System.out.println("Query 1 : " + query.getResultList());
		return new ArrayList<Contact>();
		//return query.getResultList();
	}

	// Retrieves all the guests:
	/*public List<Contact> getAllContacts() {
		System.out.println("in get contacts");
		Query query = entityManager.createQuery("FROM Contact");
		System.out.println("Query : " + query);
		//System.out.println("Query 1 : " + query.getResultList());
		return query.getResultList();
	}*/
}
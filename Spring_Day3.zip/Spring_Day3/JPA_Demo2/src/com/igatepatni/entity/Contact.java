package com.igatepatni.entity;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Contact implements Serializable {
    @Override
	public String toString() {
		return "Contact [dob=" + dob + ", email=" + email + ", id=" + id
				+ ", name=" + name + "]";
	}

	public Contact() {
		super();
	}

    public Contact(String name, String email) {
        this.name = name;
        this.email = email;
        this.dob = new Date(System.currentTimeMillis());
    }
    
    @Id @GeneratedValue
    Long id;
    private String name;
    public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public Date getDob() {
		return dob;
	}



	public void setDob(Date dob) {
		this.dob = dob;
	}

	private String email;
    private Date dob;

   

   

    
}
package com.journaldev.spring.jdbc.service;

import org.springframework.transaction.annotation.Transactional;

import com.journaldev.spring.jdbc.dao.CustomerDAO;
import com.journaldev.spring.jdbc.model.Customer;

public class CustomerManagerImpl implements CustomerManager {

	private CustomerDAO customerDAO;

	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}

	/*
	 * Propogation mode: Required read-only :false isolation level:
	 * READ_COMMITTED rollback: No roll back for checked exception
	 */
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public void createCustomer(Customer cust) {
		// begin Transaction - Proxy AOP
		
		//tx.begin();
		customerDAO.create(cust);
		//tx.commit() or tx.rollback()
		// commit or rollback - AOP
	}

}

package com.igatepatni.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query; //import javax.persistence.TypedQuery;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.igatepatni.entity.Contact;

@Component("contactDao")
public class ContactDao {
	// Injected database connection

	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	// Stores a new guest:
	@Transactional
	public void persist(Contact contact) {
	
		entityManager.persist(contact);
		
	}

	// Retrieves all the guests:
	public List<Contact> getAllContacts() {
		System.out.println("in get contacts");
		Query query = entityManager.createQuery("FROM Contact");
		System.out.println("Query : " + query);
		//System.out.println("Query 1 : " + query.getResultList());
		return query.getResultList();
	}
}
package com.cg;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class CustomerDAOImpl {

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	// @Transactional(propagation=Propagation.REQUIRES_NEW)
	public void create(int id) {
		// Starts a transaction here
		System.out.println("Called Original insert .....");
		String queryCustomer = "insert into Customer_Tx (id, name) values (?,?)";
		int i = 10;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		jdbcTemplate.update(queryCustomer, new Object[] { id, "Original" });
	}

	public void createDummy(int id) throws SQLException {
		System.out.println("Called Dummy insert .....");
		String queryCustomer2 = "insert into Customer_Tx (id, name) values (?,?)";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		jdbcTemplate.update(queryCustomer2, new Object[] {id,
				"Dummy" });
		System.out.println("Inserted into Customer Table Successfully");
		// throw new DuplicateKeyException("Key Invalid");
		// throw new SQLException();
		// Commit
	}

	public void read() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List values = jdbcTemplate.queryForList("SELECT * FROM Customer_Tx");
		for (Object e : values) {
			// Customer c1=(Customer)e;
			System.out.println(e);
		}

	}

}

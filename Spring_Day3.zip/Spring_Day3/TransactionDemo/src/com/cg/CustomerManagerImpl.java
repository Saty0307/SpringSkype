package com.cg;

import java.sql.SQLException;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class CustomerManagerImpl  {

	private CustomerDAOImpl customerDAO;

	public void setCustomerDAO(CustomerDAOImpl customerDAO) {
		this.customerDAO = customerDAO;
	}

	/*
	 * Propogation mode: Required read-only :false isolation level:
	 * READ_COMMITTED rollback: No roll back for checked exception
	 */

//	@Transactional(rollbackFor = SQLException.class)
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public void createCustomer(Customer cust) throws SQLException {
		// begin Transaction - Proxy AOP
		customerDAO.create(29);
		customerDAO.createDummy(29);
		// commit or rollback - AOP
	}
	

	public void doInsert(Customer cust) throws SQLException {
		// begin Transaction - Proxy AOP
		customerDAO.create(30);
		customerDAO.createDummy(256789);
		// commit or rollback - AOP
	}
	
	@Transactional(isolation=Isolation.READ_UNCOMMITTED)
	public void readCustomer() {
		// begin Transaction - Proxy AOP
		customerDAO.read();
		// commit or rollback - AOP
	}

}

package com.cg;

import java.sql.SQLException;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TransactionManagerMain {

	public static void main(String[] args) throws SQLException{
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"spring.xml");

		CustomerManagerImpl customerManager = ctx.getBean("customerManager",
				CustomerManagerImpl.class);

		Customer cust = createDummyCustomer();
		//customerManager.createCustomer(cust);
		customerManager.createCustomer(cust);
		customerManager.doInsert(cust);
		//customerManager.readCustomer();

		ctx.close();
	}

	private static Customer createDummyCustomer() {
		Customer customer = new Customer();
		customer.setId(7);
		customer.setName("Ian");
		return customer;
	}

}

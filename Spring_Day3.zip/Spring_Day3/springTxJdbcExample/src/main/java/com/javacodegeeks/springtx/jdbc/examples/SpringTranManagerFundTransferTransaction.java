package com.javacodegeeks.springtx.jdbc.examples;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

/*
 * This class uses TransactionManager
 * 
 * 1) Create a dataSource
 * 2) Create a PlatformTransactionManager - wire the dataSource - created in Step 1
 * 3) In this class wire the PlatformTransactionManager  - created in Step 2 and wire dataSource -- created in Step 1
 */


public class SpringTranManagerFundTransferTransaction extends FundManagerDao implements FundManager {
	private PlatformTransactionManager transactionManager;

	public void setTransactionManager(PlatformTransactionManager txManager) {
		this.transactionManager = txManager;
	}


	public void transfer(int accountNbr1, int accountNbr2, int amount) throws Exception {
		TransactionDefinition txDef = new DefaultTransactionDefinition();
		TransactionStatus txStatus = transactionManager.getTransaction(txDef);
		try {
			doTransfer(accountNbr1, accountNbr2, amount);
			transactionManager.commit(txStatus);
		} catch (Exception e) {
			transactionManager.rollback(txStatus);
			throw e;
		}
	}
}

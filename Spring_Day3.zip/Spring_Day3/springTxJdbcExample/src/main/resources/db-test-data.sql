drop table Account;
CREATE TABLE Account(
ID NUMBER(5) PRIMARY KEY,
NAME VARCHAR2(20),
BALANCE NUMBER(7,2));
insert into account(id, name, balance) values (1, 'Joe', 2000);
insert into account(id, name, balance) values (2, 'Jim', 1000);
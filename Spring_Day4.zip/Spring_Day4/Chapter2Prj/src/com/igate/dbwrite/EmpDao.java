package com.igate.dbwrite;

import com.igate.simplereadwrite.Employee;

public interface EmpDao {
	public void save(final Employee item);
}

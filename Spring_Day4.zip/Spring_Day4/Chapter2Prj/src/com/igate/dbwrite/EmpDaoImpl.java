package com.igate.dbwrite;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.igate.simplereadwrite.Employee;

@Repository("empDao")
public class EmpDaoImpl implements EmpDao{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/*
	 * 
	 * 
 		CREATE TABLE SB_EMP_AUG(
   		empid NUMBER(5),
    	ename VARCHAR2(10),
    	title VARCHAR2(10),
   		salary NUMBER(5),
    	rank VARCHAR2(10)
    	);
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void save(final Employee item) {
		jdbcTemplate.update(
						"insert into sb_emp_aug (empid, ename, title,salary,rank) values(?,?,?,?,?)",
						new PreparedStatementSetter() {
							public void setValues(PreparedStatement stmt)
									throws SQLException {
								stmt.setInt(1, item.getEmpid());
								stmt.setString(2, item.getEname());
								stmt.setString(3, item.getTitle());
								stmt.setInt(4, item.getSalary());
								stmt.setString(5, item.getRank());
							}
						});
	}
}

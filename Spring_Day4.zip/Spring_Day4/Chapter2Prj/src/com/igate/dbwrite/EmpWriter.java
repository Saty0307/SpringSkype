package com.igate.dbwrite;

import java.util.Iterator;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.simplereadwrite.Employee;

@Component("empWriter")
public class EmpWriter implements ItemWriter {
	@Autowired
	private EmpDao empDao;

	public void write(List items) throws Exception {
		for (Iterator<Employee> iterator = items.iterator(); iterator.hasNext();) {
			Employee item = iterator.next();
			//System.out.println("Emp obj in writer : " + item);
			empDao.save(item);
		}
	}
}

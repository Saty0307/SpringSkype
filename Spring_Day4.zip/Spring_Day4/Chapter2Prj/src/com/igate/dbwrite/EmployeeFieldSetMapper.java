package com.igate.dbwrite;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;

import com.igate.simplereadwrite.Employee;


@Component("empMapper")
public class EmployeeFieldSetMapper implements FieldSetMapper<Employee> {
	 
    public Employee mapFieldSet(FieldSet fieldSet) throws BindException {
        if(fieldSet == null) return null;
         
        Employee emp = new Employee(); 
        // unlike jdbc the index is 0 based
        emp.setEmpid(fieldSet.readInt(0));
        emp.setEname(fieldSet.readString(1));
        emp.setTitle(fieldSet.readString(2));
        emp.setSalary(fieldSet.readInt(3));
         
        return emp;
    }
 
}

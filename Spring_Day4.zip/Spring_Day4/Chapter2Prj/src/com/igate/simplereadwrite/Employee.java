package com.igate.simplereadwrite;

public class Employee {

	Integer empid, salary;
	String ename, title, rank;

	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public Employee(Integer empid, Integer salary, String ename, String title,
			String rank) {
		super();
		this.empid = empid;
		this.salary = salary;
		this.ename = ename;
		this.title = title;
		this.rank = rank;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Emp [empid=" + empid + ", ename=" + ename + ", rank=" + rank
				+ ", salary=" + salary + ", title=" + title + "]";
	}
}

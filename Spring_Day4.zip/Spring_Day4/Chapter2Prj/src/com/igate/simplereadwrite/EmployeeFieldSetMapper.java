package com.igate.simplereadwrite;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class EmployeeFieldSetMapper implements FieldSetMapper<Employee> {
	 
    public Employee mapFieldSet(FieldSet fieldSet) throws BindException {
        if(fieldSet == null) return null;
         
        Employee emp = new Employee(); 
        // unlike jdbc the index is 0 based
        emp.setEmpid(fieldSet.readInt(0));
        emp.setEname(fieldSet.readString(1));
        emp.setTitle(fieldSet.readString(2));
        emp.setSalary(fieldSet.readInt(3));
         
        return emp;
    }
 
}

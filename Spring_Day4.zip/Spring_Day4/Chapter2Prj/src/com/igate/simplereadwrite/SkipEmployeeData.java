package com.igate.simplereadwrite;

import org.springframework.batch.core.annotation.OnSkipInProcess;
import org.springframework.batch.core.annotation.OnSkipInRead;
import org.springframework.batch.core.annotation.OnSkipInWrite;

public class SkipEmployeeData{

	@OnSkipInRead
    void onSkipInRead(Throwable t){
    	System.out.println("In Skip....Falied to read Emp");
    };
    
    @OnSkipInProcess
    void onSkipInProcess(Employee item, Throwable t){
    	System.out.println("In Skip....Falied to process ->"+item);
    	
    };
    
    @OnSkipInWrite
    void onSkipInWrite(Employee item, Throwable t){
    	System.out.println("In Skip....Falied to write Emp");
    };

}
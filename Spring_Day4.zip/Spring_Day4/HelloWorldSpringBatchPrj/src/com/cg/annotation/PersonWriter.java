package com.cg.annotation;

import java.util.Iterator;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component("personWriter")
public class PersonWriter implements ItemWriter {

	public void write(List items) throws Exception {
		for (Iterator<Person> iterator = items.iterator(); iterator.hasNext();) {
			Person item = iterator.next();
			//System.out.println("Emp obj in writer : " + item);
			System.out.println(item.getFirstName()+" "+item.getLastName());
		}
	}
}

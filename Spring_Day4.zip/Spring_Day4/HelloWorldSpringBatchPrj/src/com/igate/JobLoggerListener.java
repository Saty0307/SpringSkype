package com.igate;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.annotation.AfterJob;
import org.springframework.batch.core.annotation.BeforeJob;


public class JobLoggerListener {
	@BeforeJob
	public void m1(JobExecution jobExecution) {
		System.out.println("From Listener..."+jobExecution.getJobInstance().getJobName()
				+ " is beginning execution");
	}

	@AfterJob
	public void m2(JobExecution jobExecution) {
		System.out.println("From Listener..."+jobExecution.getJobInstance().getJobName()
				+ " has completed with the status " + jobExecution.getStatus());
	}
	
}

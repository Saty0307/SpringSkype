package com.igate;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

public class Tasklet2 implements Tasklet{
	

	@Override
	public RepeatStatus  execute(StepContribution arg0, ChunkContext context)
			throws Exception {
		
		String name =
			(String) context.getStepContext().getJobParameters().get("parameter1");
		
		String bu =
				(String) context.getStepContext().getJobParameters().get("parameter2");
	
	System.out.println("---------------------------");
	 System.out.println("Copyright "+bu+"@"+name);

		return RepeatStatus.FINISHED; //Tells the task is over (no need to repeat)
	}
	
}


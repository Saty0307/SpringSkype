package com.igate.conditionaljob;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LaunchConditionaljob {
	public static void main(String... args) throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"conditionalstepjob.xml");
		JobLauncher jobLauncher = context.getBean(JobLauncher.class);
		Job job = context.getBean(Job.class);
		System.out.println("Launching the job....");
	
		JobExecution jobExecution = jobLauncher.run(job, new JobParameters());
		
		System.out.println("\n Job ended with status: "
				+ jobExecution.getExitStatus());
	}
}

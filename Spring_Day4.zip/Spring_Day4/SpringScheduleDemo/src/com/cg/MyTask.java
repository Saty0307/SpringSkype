package com.cg;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@Component
public class MyTask {

	//@Scheduled(cron="1 0/1 * * * ?")
//	@Scheduled(cron="*/5 * * * * ?")
  // @Scheduled(fixedRate=5000)
	@Scheduled(fixedDelay = 1000, initialDelay = 3000)
    public void work() {
	       System.out.println("Called");
    }
   
  // @Scheduled(fixedRate=2000)
    public void display() {
	       System.out.println("in display");
    }
   
  // @Scheduled(fixedRate=10000)
   public void message() {
	       System.out.println("The message is ....");
   }
}

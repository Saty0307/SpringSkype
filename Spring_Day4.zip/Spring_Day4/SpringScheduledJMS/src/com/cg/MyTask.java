package com.cg;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MyTask {
	static int count=1;
	
	@Autowired
	private JmsTemplate template = null;

	@Scheduled(fixedDelay = 2000, initialDelay = 3000)
    public void work() {
		System.out.println("Hai");
		template.send(new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {

				TextMessage message = session.createTextMessage("Welcome "+count);
				message.setIntProperty("message_count", count);
				System.out.println("Sending message: " + count);
				count++;
				return message;
			}
		});
    }
}

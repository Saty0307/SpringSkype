package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class SampleApplication {

	public static void main(String[] args){
		ApplicationContext context = new ClassPathXmlApplicationContext("message-context.xml");
        context.getBean(MyTask.class);
	}
}

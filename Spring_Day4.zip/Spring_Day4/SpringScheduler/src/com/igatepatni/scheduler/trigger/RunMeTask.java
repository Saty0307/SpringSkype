package com.igatepatni.scheduler.trigger;
 
public class RunMeTask 
{
	public void printMe() {
		System.out.println("Run Me ~");
	}
}